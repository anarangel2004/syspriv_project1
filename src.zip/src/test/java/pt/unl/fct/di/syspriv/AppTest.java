package pt.unl.fct.di.syspriv;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import pt.unl.fct.di.syspriv.entities.Patient;
import pt.unl.fct.di.syspriv.storage.Hibernate;
import pt.unl.fct.di.syspriv.xacml.XACMLPDP;

/**
 * Unit test for simple App.
 */
public class AppTest {

    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        assertTrue(true);
    }

    @Test
    public void shouldAllowPatientToOwnData() throws Exception{
        var db = Hibernate.getInstance();
        var pdp = new XACMLPDP();
        var patients = db.sql("SELECT * FROM patients", Patient.class);
        for (var patient : patients){
            var canAccess = pdp.checkAccess(patient, patient, "something irrelevant");
            assertTrue(canAccess);
        }
    }

    @Test
    public void shouldAllowEmployeeToOwnData() throws Exception{
        var db = Hibernate.getInstance();
        var pdp = new XACMLPDP();
        var employees = db.sql("SELECT * FROM employees", Patient.class);
        for (var employee : employees){
            var canAccess = pdp.checkAccess(employee, employee, "something irrelevant");
            assertTrue(canAccess);
        }
    }
}
